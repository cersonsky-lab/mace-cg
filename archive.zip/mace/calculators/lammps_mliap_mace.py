import logging
import os
import sys
import time
from contextlib import contextmanager
from typing import Dict, Tuple

import numpy as np
import torch
from ase.data import chemical_symbols
from e3nn.util.jit import compile_mode

try:
    from lammps.mliap.mliap_unified_abc import MLIAPUnified
except ImportError:

    class MLIAPUnified:
        def __init__(self):
            pass


class MACELammpsConfig:
    """Configuration settings for MACE-LAMMPS integration."""

    def __init__(self):
        self.debug_time = self._get_env_bool("MACE_TIME", False)
        self.debug_profile = self._get_env_bool("MACE_PROFILE", False)
        self.profile_start_step = int(os.environ.get("MACE_PROFILE_START", "5"))
        self.profile_end_step = int(os.environ.get("MACE_PROFILE_END", "10"))
        self.allow_cpu = self._get_env_bool("MACE_ALLOW_CPU", False)
        self.force_cpu = self._get_env_bool("MACE_FORCE_CPU", False)

    @staticmethod
    def _get_env_bool(var_name: str, default: bool) -> bool:
        return os.environ.get(var_name, str(default)).lower() in (
            "true",
            "1",
            "t",
            "yes",
        )


@contextmanager
def timer(name: str, enabled: bool = True):
    """Context manager for timing code blocks."""
    if not enabled:
        yield
        return

    start = time.perf_counter()
    try:
        yield
    finally:
        elapsed = time.perf_counter() - start
        logging.info(f"Timer - {name}: {elapsed*1000:.3f} ms")


@compile_mode("script")
class MACEEdgeForcesWrapper(torch.nn.Module):
    """Wrapper that adds per-pair force computation to a MACE model."""

    def __init__(self, model: torch.nn.Module, **kwargs):
        super().__init__()
        self.model = model
        self.register_buffer("atomic_numbers", model.atomic_numbers)
        self.register_buffer("r_max", model.r_max)
        self.register_buffer("num_interactions", model.num_interactions)
        # From the model, not the process default. These feed the forward beside
        # the model's own tensors, and the export used to land on the right dtype
        # only as a side effect: `--format mliap` converts to cueq first, and that
        # converter set the default globally on its way through. Now that it
        # restores it, a global would hand a float64 export float32 buffers, which
        # dtype promotion turns into a wrong number under LAMMPS rather than an
        # error here. `r_max` is where `LAMMPS_MLIAP_MACE` reads its dtype too, so
        # the wrapper and the coupling cannot disagree.
        dtype = model.r_max.dtype
        self.register_buffer(
            "total_charge",
            kwargs.get("total_charge", torch.tensor([0.0], dtype=dtype)),
        )
        self.register_buffer(
            "total_spin",
            kwargs.get("total_spin", torch.tensor([1.0], dtype=dtype)),
        )

        if not hasattr(model, "heads"):
            model.heads = ["Default"]

        head_name = kwargs.get("head", model.heads[-1])
        head_idx = model.heads.index(head_name)
        self.register_buffer("head", torch.tensor([head_idx], dtype=torch.long))

        for p in self.model.parameters():
            p.requires_grad = False

    def forward(
        self, data: Dict[str, torch.Tensor]
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Compute energies and per-pair forces."""
        data["head"] = self.head
        data["total_charge"] = self.total_charge
        data["total_spin"] = self.total_spin

        out = self.model(
            data,
            training=False,
            compute_force=False,
            compute_virials=False,
            compute_stress=False,
            compute_displacement=False,
            compute_edge_forces=True,
            lammps_mliap=True,
        )

        node_energy = out["node_energy"]
        pair_forces = out["edge_forces"]
        total_energy = out["energy"][0]

        if pair_forces is None:
            pair_forces = torch.zeros_like(data["vectors"])

        return total_energy, node_energy, pair_forces


class LAMMPS_MLIAP_MACE(MLIAPUnified):
    """MACE integration for LAMMPS using the MLIAP interface."""

    def __init__(self, model, **kwargs):
        super().__init__()
        self.config = MACELammpsConfig()
        self.model = MACEEdgeForcesWrapper(model, **kwargs)
        self.element_types = [chemical_symbols[s] for s in model.atomic_numbers]
        self.num_species = len(self.element_types)
        self.rcutfac = 0.5 * float(model.r_max)
        self.ndescriptors = 1
        self.nparams = 1
        self.dtype = model.r_max.dtype
        self.device = "cpu"
        self.initialized = False
        self.step = 0

    def _initialize_device(self, data):
        using_kokkos = "kokkos" in data.__class__.__module__.lower()

        if using_kokkos and not self.config.force_cpu:
            device = torch.as_tensor(data.elems).device
            if device.type == "cpu" and not self.config.allow_cpu:
                raise ValueError(
                    "GPU requested but tensor is on CPU. Set MACE_ALLOW_CPU=true to allow CPU computation."
                )
        else:
            device = torch.device("cpu")

        self.device = device
        self.model = self.model.to(device)
        logging.info(f"MACE model initialized on device: {device}")
        self.initialized = True

    def _check_ghost_exchange_support(self, data):
        """Fail early when the build cannot exchange ghost node features.

        Every interaction layer past the first needs the node features of the
        ghost atoms, which only LAMMPS can fill in. The call that does it,
        ``forward_exchange``, exists solely in the KOKKOS coupling
        (``src/KOKKOS/mliap_unified_couple_kokkos.pyx``); the plain ML-IAP
        ``MLIAPDataPy`` has no such method, so a stock non-KOKKOS build used
        to reach the second layer and die there on a bare ``AttributeError``
        with nothing pointing at the build.
        """
        num_interactions = int(self.model.num_interactions)
        if num_interactions <= 1 or hasattr(data, "forward_exchange"):
            return
        raise RuntimeError(
            f"This MACE model has {num_interactions} interaction layers, so it "
            f"needs LAMMPS to exchange ghost-atom features between layers, but "
            f"{type(data).__module__}.{type(data).__name__} provides no "
            f"forward_exchange(). That call only exists in LAMMPS's KOKKOS "
            f"ML-IAP coupling: rebuild LAMMPS with -D PKG_KOKKOS=yes and run "
            f"it with '-k on -sf kk', or export a single-layer model."
        )

    def compute_forces(self, data):
        natoms = data.nlocal
        ntotal = data.ntotal
        nghosts = ntotal - natoms
        npairs = data.npairs
        species = torch.as_tensor(data.elems, dtype=torch.int64)

        if not self.initialized:
            self._initialize_device(data)
            self._check_ghost_exchange_support(data)

        self.step += 1
        self._manage_profiling()

        if natoms == 0 or npairs <= 1:
            return

        with timer("total_step", enabled=self.config.debug_time):
            with timer("prepare_batch", enabled=self.config.debug_time):
                batch = self._prepare_batch(data, natoms, nghosts, species)

            with timer("model_forward", enabled=self.config.debug_time):
                _, atom_energies, pair_forces = self.model(batch)

                if self.device.type != "cpu":
                    torch.cuda.synchronize()

            with timer("update_lammps", enabled=self.config.debug_time):
                self._update_lammps_data(data, atom_energies, pair_forces, natoms)

    def _prepare_batch(self, data, natoms, nghosts, species):
        """Prepare the input batch for the MACE model."""
        return {
            "vectors": torch.as_tensor(data.rij).to(self.dtype).to(self.device),
            "node_attrs": torch.nn.functional.one_hot(
                species.to(self.device), num_classes=self.num_species
            ).to(self.dtype),
            "edge_index": torch.stack(
                [
                    torch.as_tensor(data.pair_j, dtype=torch.int64).to(self.device),
                    torch.as_tensor(data.pair_i, dtype=torch.int64).to(self.device),
                ],
                dim=0,
            ),
            "batch": torch.zeros(natoms, dtype=torch.int64, device=self.device),
            "lammps_class": data,
            "natoms": (natoms, nghosts),
        }

    def _update_lammps_data(self, data, atom_energies, pair_forces, natoms):
        """Write per-atom energies and pair forces back into LAMMPS.

        The two ML-IAP couplings expose two different writeback APIs, and only
        the KOKKOS one takes device pointers: its ``MLIAPDataPy`` has an
        ``eatoms`` getter (a view to copy into) and ``update_pair_forces_gpu``.
        The plain coupling (``src/ML-IAP/mliap_unified_couple.pyx``) declares
        ``eatoms`` write-only and offers only ``update_pair_forces``, which
        wants a contiguous host array -- so on a stock non-KOKKOS build the
        model used to run to completion and then die here on ``property
        'eatoms' ... has no getter``, three frames below anything that names
        the build. Both branches end in the same C ``update_pair_forces``;
        only where the pointer comes from differs.
        """
        atom_energies_real = atom_energies[:natoms].detach().double()
        total_energy = atom_energies_real.sum().item()
        pair_forces = pair_forces.detach().double()

        if hasattr(data, "update_pair_forces_gpu"):
            torch.as_tensor(data.eatoms).copy_(atom_energies_real)
            data.energy = total_energy
            data.update_pair_forces_gpu(pair_forces)
            return

        # The write-only setter fills exactly nlistatoms doubles and Cython
        # rejects a length mismatch, so say which two counts disagree rather
        # than leaving a bare ValueError from inside the .pyx. The KOKKOS
        # branch above assumes the same equality (its getter is sized by
        # nlistatoms while the slice is sized by nlocal).
        nlistatoms = int(getattr(data, "nlistatoms", natoms))
        if nlistatoms != natoms:
            raise RuntimeError(
                f"LAMMPS expects {nlistatoms} per-atom energies (nlistatoms) "
                f"but this step computed {natoms} (nlocal). The ML-IAP "
                f"writeback needs the two to agree."
            )
        data.eatoms = atom_energies_real.cpu().numpy()
        data.energy = total_energy
        data.update_pair_forces(np.ascontiguousarray(pair_forces.cpu().numpy()))

    def _manage_profiling(self):
        if not self.config.debug_profile:
            return

        if self.step == self.config.profile_start_step:
            logging.info(f"Starting CUDA profiler at step {self.step}")
            torch.cuda.profiler.start()

        if self.step == self.config.profile_end_step:
            logging.info(f"Stopping CUDA profiler at step {self.step}")
            torch.cuda.profiler.stop()
            logging.info("Profiling complete. Exiting.")
            sys.exit()

    def compute_descriptors(self, data):
        pass

    def compute_gradients(self, data):
        pass
